<?php 
include 'config.php';
$us = $_POST['username'];
$pass = $_POST['pass'];

$login = mysqli_query($conn,"SELECT * FROM user WHERE username ='$us' and pass = '$pass'");
$cek = mysqli_num_rows ($login);
 
if($cek > 0){
	session_start();
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login ";
	header("location:uts.php");
}else {
    echo "
        <script>
            alert('Login gagal');
            document.location.href = 'index.php';
        </script>
        ";
    // header("location: index.php");
}
?>	
