<?php
// panggil koneksi database
include "koneksi.php";

// simpan data
if (isset($_POST['bsimpan'])) {
    // simpan data baru
    $simpan = mysqli_query($koneksi, "INSERT INTO tmhs(nim, nama, dosen, status, ket)
                                        VALUES ('$_POST[tnim]',
                                                '$_POST[tnama]',
                                                '$_POST[tdosen]',
                                                '$_POST[tstatus]',
                                                '$_POST[tket]') ");
    // jika simpan sukses
    if($simpan){
        echo "<script>
                alert('Data Anda Berhasil Disimpan');
                document.location='uts.php';
              </script>";
    } else {
        echo "<script>
                alert('Data Anda Belum Tersimpan');
                document.location='uts.php';
              </script>";
    }
}

// ubah data
if (isset($_POST['bedit'])) {
  // simpan data baru
  $ubah = mysqli_query($koneksi, "UPDATE tmhs SET
                                                    nim = '$_POST[tnim]',
                                                    nama = '$_POST[tnama]',
                                                    dosen = '$_POST[tdosen]',
                                                    status = '$_POST[tstatus]',
                                                    ket = '$_POST[tket]'
                                                  WHERE id_mhs = '$_POST[id_mhs]' 
                                                    ");
  // jika simpan sukses
  if($ubah){
      echo "<script>
              alert('Data Anda Berhasil Diubah');
              document.location='uts.php';
            </script>";
  } else {
      echo "<script>
              alert('Data Anda belum di Ubah ');
              document.location='uts.php';
            </script>";
  }
}

// Hapus Data
if (isset($_POST['bhapus'])) {

  // Hapus data 
  $hapus = mysqli_query($koneksi, "DELETE FROM tmhs WHERE id_mhs = '$_POST[id_mhs]' ");

  // jika Hapus sukses

  if($hapus){
      echo "<script>
              alert('Data Berhasil Di Hapus');
              document.location='uts.php';
            </script>";
  } else {
      echo "<script>
              alert('Data Belum Berhasil Di Hapus ');
              document.location='uts.php';
            </script>";
  }
}
