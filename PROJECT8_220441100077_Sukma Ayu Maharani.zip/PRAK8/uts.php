<?php
  // panggil koneksi Database
  include "koneksi.php";
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UTS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="uts.css">
</head>
  <body>
      <nav class="navbar bg-primary fixed-top style-bg">
        <div class="container">
            <div class="navbar style-logo">PBW</div>
            <div class="navbar user">Selamat Datang, Sukma Ayu Maharani</div>
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
              <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Praktikum PBW A</h5>
              <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <ul class="navbar-nav left-content-end flex-grow-1 pe-3">
                  <li class="nav-item">
                    <a class="nav-link style-home active" aria-current="page" href="modul5.php">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link style-dm active" href="#">Daftar Mahasiswa</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Informasi Tugas</a>
                  </li>
                  <div class="d-grid gap-2 col-6 mx-auto">
                    <button class="btn btn-danger" type="button">Log Out</button>
                  </div>
                </div>
            </div>
     </nav>
    <!-- BUAT JUDUL KONTEN-->
    <div class="teks">
      <h1 align="center"> DAFTAR MAHASISWA<br>PRAKTIKUM PEMROGRAMAN BERBASIS WEB </h1>
    </div>
    </div>
    <br>
    <!-- BUAT TABEL -->
        <div class="pencari">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">
              Tambah Data
            </button>
            <td><a href="" class="btn btn-danger">Cetak Laporan</a></a></td>
            <span>
                <input type="text" style= "float: right;" placeholder="Cari Berdasarkan NIM"><span class="glyphicon glyphicon-name" > </input> </span> 
            </span>
        </div>
    </div>
    <br>

    <table class="table">
        <thead>
          <tr class="table-primary" align="center">
            <th scope="col">No</th>
            <th scope="col">NIM</th>
            <th scope="col">NAMA</th>
            <th scope="col">Dosen</th>
            <th scope="col">Status</th>
            <th scope="col">Ket</th>
            <th colspan ="3" scope="col">Aksi</th>
          </tr>
          <?php
          // persiapan menampilkan data
          $no = 1;
          $tampil = mysqli_query($koneksi, "SELECT * FROM tmhs ORDER BY id_mhs ASC");
          while($data = mysqli_fetch_array($tampil)):
          ?>
        </thead>
        <tbody>
          <tr>
            <td><?= $no++?></td>
            <td><?=$data['nim']?></td>
            <td><?=$data['nama']?></td>
            <td><?=$data['dosen']?></td>
            <td><?=$data['status']?></td>
            <td><?=$data['ket']?></td>
            <td><a href="" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalUbah<?=$no?>">Edit</a></td>
            <td><a href="" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalHapus<?=$no?>">Hapus</a></td>
          </tr>
<!-- Awal Modal Ubah -->
          <div class="modal fade" id="modalUbah<?= $no ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Data Mahasiswa</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form action="aksi_crud.php" method="post">
            <input type="hidden" name="id_mhs" value="<?= $data['id_mhs'] ?>">
             <div class="modal-body">

          <div class="mb-3">
            <label class="form-label">NIM</label>
             <input type="text" class="form-control" name="tnim" value= "<?= $data['nim']?>" placeholder="Masukan NIM ">
          </div>

          <div class="mb-3">
          <label class="form-label">NAMA</label>
            <input type="text" class="form-control" name="tnama" value= "<?= $data['nama']?>" placeholder="Masukan Nama Anda ">
          </div>

          <div class="mb-3">
          <label class="form-label">Dosen</label>
            <input type="text" class="form-control" name="tdosen" value= "<?= $data['dosen']?>" placeholder="Masukan Nama Dosen ">
          </div>

          <div class="mb-3">
          <label class="form-label">Status</label>
            <input type="text" class="form-control" name="tstatus" value= "<?= $data['dosen']?>" placeholder="Masukan Status Anda ">
          </div>

          <div class="mb-3">
          <label class="form-label">Ket</label>
            <input type="text" class="form-control" name="tket" value= "<?= $data['ket']?>" placeholder="Masukan Keterangan  ">
          </div>        
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-warning" name="bedit">Edit</button>
          <!-- <button type="submit" class="btn btn-danger" data-bs-dismiss="modal">Keluar</button> -->
          
          </div>
      </form>

        </div>
      </div>
    
  </div>
<!-- ahkir modal Ubah -->
<!-- Awal Modal Hapus --> 
          <div class="modal fade" id="modalHapus<?= $no ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5" id="staticBackdropLabel">Konfirmasi Data Yang Ingin Anda Hapus</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form action="aksi_crud.php" method="post">
            <input type="hidden" name="id_mhs" value="<?= $data['id_mhs'] ?>">
             <div class="modal-body">
              <h5 class="text-center">Apakah Anda Yakin Akan Menghapus Data Ini?<br>
                <span class="text-warning"><?= $data['nim']?> - <?= $data['nama']?> </span>
              </h5>
                
        <div class="modal-footer">
          <button type="submit" class="btn btn-warning" name="bhapus" >Hapus</button>
          <!-- <button type="submit" class="btn btn-danger" data-bs-dismiss="modal">Keluar</button> -->
          </div>
      </form>

        </div>
      </div>
    
  </div>
<!-- ahkir modal Hapus -->
          <?php endwhile;?>
        </tbody>
      </table>
<!-- Awal Modal -->
  <div class="modal fade" id="modalTambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
     <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Data Mahasiswa</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
      <form action="aksi_crud.php" method="post">
        <input type="hidden" name="id_mhs" value="<?=$data['id_mhs']?>">
       <div class="modal-body">

        <div class="mb-3">
          <label class="form-label">NIM</label>
            <input type="text" class="form-control" name="tnim" placeholder="Masukan NIM ">
          </div>

          <div class="mb-3">
          <label class="form-label">NAMA</label>
            <input type="text" class="form-control" name="tnama" placeholder="Masukan Nama Anda ">
          </div>

          <div class="mb-3">
          <label class="form-label">Dosen</label>
            <input type="text" class="form-control" name="tdosen" placeholder="Masukan Nama Dosen ">
          </div>

          <div class="mb-3">
          <label class="form-label">Status</label>
            <input type="text" class="form-control" name="tstatus" placeholder="Masukan Status Anda ">
          </div>

          <div class="mb-3">
          <label class="form-label">Ket</label>
            <input type="text" class="form-control" name="tket" placeholder="Masukan Keterangan  ">
          </div>        
      </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-warning" name="bsimpan">Simpan</button>
          <!-- <button type="submit" class="btn btn-danger" data-bs-dismiss="modal">Keluar</button> -->
          
          </div>
      </form>
        </div>
      </div>
    
  </div>
<!-- Akhir Modal -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>